To-do List 
----------------------------------------------------------------------------------------------- 
Details:
	-->Implemented using Django, python 
	-->Implemented User Registration and Login functionality 
	-->Implemented CRUD (Create, Read, Update, Delete) functionality for the tasks 
	-->Designed webpages using HTML and CSS  
